--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5alpha1
-- Dumped by pg_dump version 9.5alpha1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE public."test-table" ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public."test-table_id_seq";
DROP TABLE public."test-table";
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: test-table; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "test-table" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at time without time zone NOT NULL,
    updated_at time without time zone NOT NULL
);


--
-- Name: test-table_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "test-table_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: test-table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "test-table_id_seq" OWNED BY "test-table".id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "test-table" ALTER COLUMN id SET DEFAULT nextval('"test-table_id_seq"'::regclass);


--
-- Data for Name: test-table; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "test-table" (id, name, created_at, updated_at) FROM stdin;
\.
COPY "test-table" (id, name, created_at, updated_at) FROM '$$PATH$$/2364.dat';

--
-- Name: test-table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"test-table_id_seq"', 1, false);


--
-- PostgreSQL database dump complete
--

